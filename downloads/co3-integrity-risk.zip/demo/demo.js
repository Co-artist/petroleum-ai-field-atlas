(function(){'use strict';
var C=JSON.parse(document.getElementById('case-config').textContent), V={};
function $(id){return document.getElementById(id)}
function fmt(x,n){return Number(x).toFixed(n===undefined?1:n)}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function row(a,b){return '<div class="read-row"><span>'+esc(a)+'</span><b>'+esc(b)+'</b></div>'}
function kpi(a,b){return '<div class="kpi"><small>'+esc(a)+'</small><b>'+esc(b)+'</b></div>'}
function scene(kind,v,m){
 var s='<svg viewBox="0 0 650 205" role="img" aria-label="随参数变化的石油场景示意图"><rect width="650" height="205" rx="12" fill="#f1f7f2"/>';
 if(kind==='co1'){
  var names=['裸眼','射孔','筛管','砾石充填'],scores={};m.rank.forEach(function(r){scores[r[0]]=r[1]});
  s+='<text x="28" y="28" font-size="11" fill="#49695a">权重：产能 '+fmt(v.production,2)+' · 成本 '+fmt(v.cost,2)+' · 控水 '+fmt(v.water,2)+'</text>';
  names.forEach(function(name,i){var x=28+i*153,score=scores[name],first=name===m.rank[0][0],color=first?'#168065':'#d6a36d';
   s+='<rect x="'+x+'" y="41" width="142" height="135" rx="9" fill="'+(first?'#e4f2eb':'#fff')+'" stroke="'+(first?'#8bc6ae':'#d7e5da')+'"/>';
   s+='<text x="'+(x+12)+'" y="61" font-size="12" font-weight="700" fill="#244e43">'+name+'</text>';
   s+='<rect x="'+(x+19)+'" y="74" width="17" height="43" fill="#8aa69a"/><rect x="'+(x+25)+'" y="74" width="5" height="43" fill="#fff"/><rect x="'+(x+36)+'" y="74" width="76" height="43" fill="#d9e8dc"/>';
   if(i===1)s+='<path d="M'+(x+37)+' 86h52 M'+(x+37)+' 103h52" stroke="#d79e69" stroke-width="3"/>';
   if(i===2)s+='<path d="M'+(x+43)+' 77v39" stroke="#168065" stroke-width="3" stroke-dasharray="4 3"/>';
   if(i===3)s+='<circle cx="'+(x+61)+'" cy="90" r="4" fill="#c69a63"/><circle cx="'+(x+79)+'" cy="101" r="4" fill="#c69a63"/>';
   s+='<rect x="'+(x+12)+'" y="130" width="101" height="9" rx="4" fill="#e5eee8"/><rect x="'+(x+12)+'" y="130" width="'+Math.max(1,score*1.01)+'" height="9" rx="4" fill="'+color+'"/>';
   s+='<text x="'+(x+12)+'" y="159" font-size="11" fill="#45695a">教学分 '+fmt(score,1)+(first?' · 首选':'')+'</text>';
  });
 } else if(kind==='co2'){
  var count=Math.round(3+(v.density-8)*5/20),r=3+(v.diameter-6)*.5,rad=(v.phase-90)*Math.PI/180;
  s+='<text x="30" y="30" font-size="11" fill="#49695a">孔密 '+v.density+' 孔/米 · 孔径 '+v.diameter+' mm · 相位角 '+v.phase+'°</text>';
  s+='<rect x="28" y="49" width="498" height="117" rx="8" fill="#dcebdc"/><rect x="28" y="49" width="74" height="117" fill="#edf4ee"/>';
  s+='<rect x="102" y="49" width="27" height="117" fill="#829d8f"/><rect x="111" y="49" width="9" height="117" fill="#fff"/>';
  s+='<text x="45" y="72" font-size="11" fill="#45695a">井筒</text><text x="137" y="72" font-size="11" fill="#45695a">储层</text>';
  for(var i=0;i<count;i++){var x=166+i*315/Math.max(1,count-1);s+='<line x1="129" y1="106" x2="'+x+'" y2="106" stroke="#d7a06c" stroke-width="4"/><circle cx="'+x+'" cy="106" r="'+r+'" fill="#d88752" stroke="#fff" stroke-width="2"/>'}
  s+='<circle cx="572" cy="100" r="35" fill="#fff" stroke="#b9d3c5" stroke-width="2"/><line x1="572" y1="100" x2="'+(572+27*Math.sin(rad))+'" y2="'+(100-27*Math.cos(rad))+'" stroke="#167d63" stroke-width="4" stroke-linecap="round"/>';
  s+='<text x="548" y="156" font-size="11" fill="#45695a">相位示意</text><text x="30" y="189" font-size="11" fill="#416856">面积 '+fmt(m.area,0)+' mm²/米 · 安全 '+fmt(m.safety,1)+' · '+(m.feasible?'满足':'未满足')+'教学约束</text>';
 } else if(kind==='co3'){
  var ps=[28,234,440],names3=['环空压差','胶结质量','振动指数'];
  ps.forEach(function(x,i){s+='<rect x="'+x+'" y="39" width="182" height="123" rx="9" fill="#fff" stroke="#d7e5da"/><text x="'+(x+13)+'" y="60" font-size="12" fill="#31594b">'+names3[i]+'</text>'});
  s+='<rect x="41" y="85" width="150" height="13" rx="6" fill="#e5eee8"/><rect x="41" y="85" width="'+(150*v.pressure/18)+'" height="13" rx="6" fill="#d7996c"/>';
  s+='<text x="41" y="124" font-size="12" fill="#244e43">'+v.pressure+' MPa</text><text x="41" y="143" font-size="10" fill="#708578">压差增大，载荷示意加长</text>';
  s+='<rect x="251" y="82" width="148" height="31" rx="6" fill="#d5e7da"/><rect x="251" y="82" width="'+(148*(100-v.bond)/100)+'" height="31" rx="6" fill="#e4b18b"/>';
  s+='<text x="247" y="140" font-size="12" fill="#244e43">胶结 '+v.bond+'/100</text>';
  var pts=[];for(var j=0;j<=24;j++){var xx=453+j*6.4,yy=101-Math.sin(j*1.4)*v.vibration*2.2;pts.push(xx+','+yy)}
  s+='<polyline points="'+pts.join(' ')+'" fill="none" stroke="#168065" stroke-width="2.5"/><text x="453" y="140" font-size="12" fill="#244e43">振动 '+v.vibration+'/10</text>';
  s+='<rect x="28" y="178" width="530" height="8" rx="4" fill="#e5eee8"/><rect x="28" y="178" width="'+(530*m.risk/100)+'" height="8" rx="4" fill="'+(m.risk>=50?'#cf805e':'#168065')+'"/>';
  s+='<text x="562" y="186" font-size="11" fill="#45695a">第 '+m.rank+'/4 位</text>';
 } else if(kind==='co4'){
  s+='<text x="28" y="30" font-size="11" fill="#49695a">水平井分段滑套：阀口高度和下方色条对应各段开度</text>';
  s+='<rect x="30" y="51" width="590" height="71" rx="9" fill="#dcebdc"/><path d="M50 91H602" stroke="#607d70" stroke-width="21" stroke-linecap="round"/><path d="M50 91H602" stroke="#fff" stroke-width="8" stroke-linecap="round"/>';
  [v.s1,v.s2,v.s3].forEach(function(open,i){var x=157+i*166,h=5+open*.46;
   s+='<rect x="'+(x-14)+'" y="'+(91-h)+'" width="28" height="'+h+'" rx="4" fill="#df9a61" stroke="#fff" stroke-width="2"/>';
   s+='<text x="'+(x-35)+'" y="146" font-size="11" fill="#31594b">第 '+(i+1)+' 段 '+open+'%</text>';
   s+='<rect x="'+(x-35)+'" y="154" width="100" height="9" rx="4" fill="#e5eee8"/><rect x="'+(x-35)+'" y="154" width="'+open+'" height="9" rx="4" fill="#168065"/>';
  });
  s+='<text x="28" y="189" font-size="11" fill="#416856">24 月油量 '+fmt(m.oil,1)+' · 含水率 '+fmt(m.water,0)+'% · 教学参考 '+m.recommended.join('/')+'%</text>';
 } else {
  var pen=Math.max(0,Math.min(650,m.penetration)),end=90+pen*.65,shots=Math.round(3+(v.density-8)*5/18),gunW=18+(v.gun-80)*.32;
  s+='<text x="28" y="30" font-size="11" fill="#49695a">文23污染带约 400 mm；橙线是合成模型的教学预测</text>';
  s+='<rect x="30" y="51" width="590" height="113" rx="8" fill="#dcebdc"/><rect x="90" y="51" width="260" height="113" fill="#e7dfcb"/>';
  s+='<rect x="'+(88-gunW)+'" y="61" width="'+gunW+'" height="91" rx="5" fill="#557d70"/>';
  for(var k=0;k<shots;k++){var sy=69+k*76/Math.max(1,shots-1);s+='<circle cx="'+(85-gunW/2)+'" cy="'+sy+'" r="3" fill="#f0af71"/>'}
  s+='<line x1="90" y1="107" x2="'+end+'" y2="107" stroke="#d6844f" stroke-width="'+(5+v.charge*.06)+'" stroke-linecap="round"/>';
  s+='<line x1="350" y1="51" x2="350" y2="164" stroke="#9c8a6b" stroke-width="2" stroke-dasharray="5 4"/>';
  s+='<text x="246" y="76" font-size="11" fill="#695d4a">污染带</text><text x="395" y="76" font-size="11" fill="#31594b">有效储层</text>';
  s+='<text x="28" y="188" font-size="11" fill="#416856">枪径 '+v.gun+' mm · 孔密 '+v.density+' 孔/米 · 预测 '+fmt(m.penetration,0)+' mm · '+(m.feasible?'满足':'未满足')+'教学筛选</text>';
 }
 return s+'</svg>';
}
function sceneCaption(kind){
 return {co1:'四张小卡表示完井方式；色条是根据左侧权重重算的教学评分，浅绿色卡是当前首选。井筒结构仅作概念示意。',
 co2:'灰色带表示套管；孔眼数量、圆孔大小和右侧指针分别映射孔密、孔径和相位角。底部状态按教学安全与出砂约束判定，面积按几何公式计算。',
 co3:'三格依次表示环空压差、胶结质量和振动信号；底部色条是教学树桩风险评分，右侧为当前井在四口井中的巡检排位。载荷与波形是相对示意。',
 co4:'横线表示水平井，三个橙色阀口及色条表示手动分段开度；下方教学参考开度来自简化模型的候选搜索，不是论文训练策略。图示不表示真实井段尺寸。',
 p1:'左侧圆点表示相对孔密，枪体宽度映射枪径，橙线长度表示合成样本模型预测穿透；虚线是文献所述约 400 mm 污染带边界。底部状态还使用教学冲击约束。'}[kind]||'';
}
function bars(items,max,label){max=max||Math.max.apply(null,items.map(function(x){return x[1]}))*1.12;var h=items.length*44+36,s='<svg viewBox="0 0 610 '+h+'" role="img" aria-label="'+esc(label)+'">';items.forEach(function(it,i){var y=16+i*44,w=Math.max(2,370*it[1]/max);s+='<text x="6" y="'+(y+15)+'" fill="#406255" font-size="12">'+esc(it[0])+'</text><rect x="150" y="'+y+'" width="370" height="24" rx="6" fill="#eef4ee"/><rect x="150" y="'+y+'" width="'+w+'" height="24" rx="6" fill="'+(i===0?'#187b61':'#d5a36e')+'"/><text x="'+(160+w)+'" y="'+(y+17)+'" fill="#183e31" font-size="12">'+fmt(it[1],it[2]||1)+'</text>'});return s+'</svg>'}
function curve(series,title){var W=610,H=260,L=52,R=20,T=20,B=34,max=Math.max.apply(null,series.reduce(function(a,s){return a.concat(s.values)},[]))*1.1,colors=['#128064','#dfa568','#587dab'];var out='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+esc(title)+'"><rect width="610" height="260" rx="10" fill="#f7faf7"/>';for(var g=0;g<5;g++){var y=T+(H-T-B)*g/4;out+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y+'" y2="'+y+'" stroke="#dbe8dd"/><text x="7" y="'+(y+4)+'" fill="#6f8677" font-size="10">'+fmt(max*(1-g/4),0)+'</text>'}series.forEach(function(s,si){var points=s.values.map(function(v,i){return (L+(W-L-R)*i/(s.values.length-1))+','+(H-B-(H-T-B)*v/max)}).join(' ');out+='<polyline points="'+points+'" fill="none" stroke="'+colors[si%colors.length]+'" stroke-width="3"/>'});return out+'</svg><div class="legend">'+series.map(function(s,i){return '<span><i style="background:'+colors[i%colors.length]+'"></i>'+esc(s.name)+'</span>'}).join('')+'</div>'}
function compareCard(label,value,detail,highlight){return '<div class="compare-option'+(highlight?' assisted':'')+'"><small>'+esc(label)+'</small><strong>'+esc(value)+'</strong><span>'+esc(detail)+'</span></div>'}
function casing(d,diam,phase){return {density:d,diameter:diam,phase:phase,area:d*Math.PI*Math.pow(diam/2,2),safety:Math.max(5,100-.8*d-1.8*diam-.035*Math.abs(phase-90)),sand:Math.min(100,15+.7*d+.45*diam)}}
function dominates(a,b){return a.area>=b.area&&a.safety>=b.safety&&a.sand<=b.sand&&(a.area>b.area||a.safety>b.safety||a.sand<b.sand)}
function casingSet(current){var ds=[8,12,16,20,24,28,current.density],di=[6,9,12,15,18,current.diameter],ph=[30,90,150,current.phase],seen={},all=[];ds.forEach(function(d){di.forEach(function(x){ph.forEach(function(p){var key=[d,x,p].join('/');if(!seen[key]){seen[key]=1;all.push(casing(d,x,p))}})})});var feasible=all.filter(function(x){return x.safety>=50&&x.sand<=38}),front=feasible.filter(function(x){return !feasible.some(function(y){return y!==x&&dominates(y,x)})});return {all:all,feasible:feasible,front:front,baseline:all.slice().sort(function(a,b){return b.area-a.area})[0],recommend:front.slice().sort(function(a,b){return b.area-a.area})[0]}}
function pareto(set,current){var frontKeys={};set.front.forEach(function(p){frontKeys[[p.density,p.diameter,p.phase].join('/')]=1});var out='<svg viewBox="0 0 610 275" role="img" aria-label="灰色不可行、浅绿可行、深绿帕累托方案、橙色当前方案的多目标散点图"><rect width="610" height="275" rx="10" fill="#f7faf7"/><path d="M55 20V230H580" fill="none" stroke="#92ad9d" stroke-width="2"/><text x="54" y="255" fill="#526a5d" font-size="11">孔眼面积 mm²/米 →</text><text x="9" y="15" fill="#526a5d" font-size="11">安全指数 ↑</text>';set.all.forEach(function(p){var key=[p.density,p.diameter,p.phase].join('/'),ok=p.safety>=50&&p.sand<=38,x=55+510*p.area/7500,y=230-2*p.safety,color=frontKeys[key]?'#188064':(ok?'#9dc8b1':'#d5dcd6'),r=frontKeys[key]?5:3;out+='<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+color+'"/>'});var x=55+510*current.area/7500,y=230-2*current.safety;return out+'<circle cx="'+x+'" cy="'+y+'" r="9" fill="#dd9259" stroke="#fff" stroke-width="2"/><text x="'+Math.min(505,x+12)+'" y="'+Math.max(25,y-8)+'" fill="#9d5c32" font-size="11">当前</text></svg><div class="legend"><span><i style="background:#d5dcd6"></i>约束外</span><span><i style="background:#9dc8b1"></i>可行</span><span><i style="background:#188064"></i>帕累托</span><span><i style="background:#dd9259"></i>当前</span></div>'}
var RISK_TREES=[{f:0,t:.35,w:.55},{f:1,t:.42,w:.50},{f:2,t:.25,w:.12},{f:2,t:.50,w:.35},{f:0,t:.65,w:.42},{f:1,t:.68,w:.38},{f:2,t:.75,w:.27},{f:0,t:.50,w:.25},{f:1,t:.55,w:.23}];
function riskEval(v){var feat=[v.pressure/18,1-v.bond/100,v.vibration/10],contrib=[0,0,0],raw=-1.65;RISK_TREES.forEach(function(t){var z=(feat[t.f]>t.t?1:-1)*t.w;contrib[t.f]+=z;raw+=z});return {risk:100/(1+Math.exp(-raw)),contrib:contrib}}
function signedBars(names,values){var out='<svg viewBox="0 0 610 164" role="img" aria-label="教学树桩特征贡献，左侧降低风险，右侧提高风险"><rect width="610" height="164" rx="10" fill="#f7faf7"/><line x1="310" y1="13" x2="310" y2="149" stroke="#95ad9e" stroke-width="2"/><text x="210" y="15" font-size="10" fill="#657a6e">降低风险 ←</text><text x="320" y="15" font-size="10" fill="#657a6e">→ 提高风险</text>';values.forEach(function(v,i){var y=34+i*40,w=Math.min(210,Math.abs(v)*90),x=v>=0?310:310-w;out+='<text x="8" y="'+(y+15)+'" font-size="11" fill="#365e4c">'+esc(names[i])+'</text><rect x="'+x+'" y="'+y+'" width="'+w+'" height="22" rx="4" fill="'+(v>=0?'#168065':'#d9a16d')+'"/><text x="'+(v>=0?x+w+7:x-39)+'" y="'+(y+15)+'" font-size="10" fill="#365e4c">'+(v>=0?'+':'')+fmt(v,2)+'</text>'});return out+'</svg>'}
function simSleeves(open){var oil=[],water=[],waterVolume=[],sum=0,wsum=0;for(var m=0;m<24;m++){var op=0,wa=0;for(var j=0;j<3;j++){var p=[1,.82,.64][j],start=[.10,.25,.48][j],cut=Math.min(.93,start+m*[.012,.018,.024][j]*open[j]);op+=p*open[j]*(1-cut);wa+=p*open[j]*cut}sum+=op;wsum+=wa;oil.push(sum);waterVolume.push(wsum);water.push(wa+op?100*wa/(wa+op):0)}return {oil:oil,water:water,waterVolume:waterVolume,oilTotal:sum,waterTotal:wsum,reward:sum-.8*wsum}}
var sleeveRef=null;function bestSleeves(){if(sleeveRef)return sleeveRef;for(var a=0;a<=100;a+=5)for(var b=0;b<=100;b+=5)for(var c=0;c<=100;c+=5){var opens=[a,b,c],result=simSleeves(opens.map(function(x){return x/100}));if(!sleeveRef||result.reward>sleeveRef.result.reward)sleeveRef={opens:opens,result:result}}return sleeveRef}
function trainToyBoost(){
 var xs=[],ys=[],keys=['charge','gun','density'];
 for(var i=0;i<160;i++){var x={charge:40+(i*31)%61,gun:80+(i*19)%51,density:8+(i*7)%19};xs.push(x);ys.push(190+2.9*x.charge+1.25*(x.gun-80)+.85*x.density+.012*(x.charge-70)*(x.gun-105)-.8*Math.pow(x.density-16,2))}
 var base=ys.reduce(function(a,b){return a+b},0)/ys.length,preds=ys.map(function(){return base}),trees=[];
 for(var t=0;t<48;t++){
  var best=null;
  keys.forEach(function(k){var vals=xs.map(function(x){return x[k]}).sort(function(a,b){return a-b});[.18,.33,.5,.67,.82].forEach(function(q){var cut=vals[Math.floor(q*(vals.length-1))],ln=0,rn=0,ls=0,rs=0;
   xs.forEach(function(x,i){var r=ys[i]-preds[i];if(x[k]<=cut){ln++;ls+=r}else{rn++;rs+=r}});if(!ln||!rn)return;var left=ls/ln,right=rs/rn,error=0;
   xs.forEach(function(x,i){var e=ys[i]-preds[i]-(x[k]<=cut?left:right);error+=e*e});if(!best||error<best.error)best={key:k,cut:cut,left:left,right:right,error:error}
  })});if(!best)break;trees.push(best);xs.forEach(function(x,i){preds[i]+=.2*(x[best.key]<=best.cut?best.left:best.right)})
 }
 return function(x){var y=base;trees.forEach(function(t){y+=.2*(x[t.key]<=t.cut?t.left:t.right)});return y};
}
var toyPredict=C.kind==='p1'?trainToyBoost():null;
function penCandidate(x){return {charge:x.charge,gun:x.gun,density:x.density,penetration:toyPredict(x),shock:25+.45*x.charge+.38*x.density}}
function penFeasible(x){return x.penetration>=400&&x.shock<=75}
var penRef=null;function bestPen(){if(penRef)return penRef;for(var ch=40;ch<=100;ch+=5)for(var gun=80;gun<=130;gun+=5)for(var d=8;d<=26;d+=2){var x=penCandidate({charge:ch,gun:gun,density:d});if(penFeasible(x)&&(!penRef||x.shock<penRef.shock||(x.shock===penRef.shock&&x.penetration>penRef.penetration)))penRef=x}return penRef}
function decisionLens(kind,o){
 var s='<svg viewBox="0 0 610 194" role="img" aria-label="随参数更新的教学决策剖析"><rect width="610" height="194" rx="10" fill="#f7faf7"/>';
 if(kind==='co1'){
  var weights=[['产能',V.production],['成本',V.cost],['控水',V.water]],sum=weights.reduce(function(a,b){return a+b[1]},0);
  s+='<text x="20" y="25" fill="#234b3f" font-size="13" font-weight="700">权重构成</text><text x="246" y="25" fill="#234b3f" font-size="13" font-weight="700">候选综合分</text>';
  weights.forEach(function(w,i){var y=49+i*41;s+='<text x="20" y="'+(y+13)+'" fill="#405c50" font-size="12">'+w[0]+'</text><rect x="68" y="'+y+'" width="135" height="18" rx="5" fill="#e6eee7"/><rect x="68" y="'+y+'" width="'+(135*w[1]/Math.max(.01,sum))+'" height="18" rx="5" fill="'+['#176b54','#a66335','#41699b'][i]+'"/>'});
  o.rank.forEach(function(r,i){var y=48+i*33,x=342+r[1]*2.1;s+='<text x="247" y="'+(y+5)+'" fill="#405c50" font-size="12">'+r[0]+'</text><line x1="342" y1="'+y+'" x2="'+x+'" y2="'+y+'" stroke="#9ec7ae" stroke-width="3"/><circle cx="'+x+'" cy="'+y+'" r="6" fill="'+(i?'#a66335':'#176b54')+'"/><text x="'+(x+10)+'" y="'+(y+5)+'" fill="#234b3f" font-size="11">'+fmt(r[1],1)+'</text>'});
 } else if(kind==='co2'){
  var set=casingSet(casing(V.density,V.diameter,V.phase)),n=[set.all.length,set.feasible.length,set.front.length],labs=['教学候选','满足安全及出砂','非支配候选'];
  s+='<text x="20" y="25" fill="#234b3f" font-size="13" font-weight="700">约束过滤漏斗 · 真实执行筛选</text>';
  n.forEach(function(v,i){var y=42+i*47,w=100+420*v/Math.max(1,n[0]),x=235-w/2+90;s+='<path d="M'+x+' '+y+'h'+w+'l-18 32h-'+(w-36)+'Z" fill="'+['#d9e9dd','#b9d7c5','#176b54'][i]+'"/><text x="20" y="'+(y+21)+'" fill="#405c50" font-size="12">'+labs[i]+'</text><text x="'+(x+w/2)+'" y="'+(y+21)+'" text-anchor="middle" fill="'+(i===2?'#fff':'#234b3f')+'" font-size="13" font-weight="700">'+v+'</text>'});
 } else if(kind==='co3'){
  var wells=[{name:'当前井',pressure:V.pressure,bond:V.bond,vibration:V.vibration},{name:'参照井 A',pressure:13,bond:82,vibration:2},{name:'参照井 B',pressure:6,bond:25,vibration:8},{name:'参照井 C',pressure:14,bond:50,vibration:6}],p=wells.slice().sort(function(a,b){return b.pressure-a.pressure}),m=wells.slice().sort(function(a,b){return riskEval(b).risk-riskEval(a).risk});
  s+='<text x="50" y="24" fill="#234b3f" font-size="13" font-weight="700">仅按压差</text><text x="455" y="24" fill="#234b3f" font-size="13" font-weight="700">多信号风险</text>';
  wells.forEach(function(w){var a=p.indexOf(w),b=m.indexOf(w),y1=48+a*33,y2=48+b*33,c=w.name==='当前井'?'#a66335':'#176b54';s+='<line x1="190" y1="'+y1+'" x2="420" y2="'+y2+'" stroke="'+c+'" stroke-width="'+(w.name==='当前井'?4:2)+'"/><circle cx="190" cy="'+y1+'" r="5" fill="'+c+'"/><circle cx="420" cy="'+y2+'" r="5" fill="'+c+'"/><text x="54" y="'+(y1+5)+'" fill="#405c50" font-size="12">'+esc(w.name)+'</text><text x="435" y="'+(y2+5)+'" fill="#405c50" font-size="12">'+esc(w.name)+'</text>'});
 } else if(kind==='co4'){
  var opens=[V.s1,V.s2,V.s3],parts=opens.map(function(a,i){var x=[0,0,0];x[i]=a/100;return simSleeves(x)}),max=Math.max.apply(null,parts.map(function(p){return p.oilTotal+p.waterTotal}).concat([1]));
  s+='<text x="20" y="25" fill="#234b3f" font-size="13" font-weight="700">各段油量与产水贡献 · 教学储层模型</text>';
  parts.forEach(function(p,i){var y=45+i*42,ow=400*p.oilTotal/max,ww=400*p.waterTotal/max;s+='<text x="20" y="'+(y+16)+'" fill="#405c50" font-size="12">第 '+(i+1)+' 段 '+opens[i]+'%</text><rect x="142" y="'+y+'" width="400" height="22" rx="5" fill="#e8eee8"/><rect x="142" y="'+y+'" width="'+ow+'" height="22" rx="5" fill="#176b54"/><rect x="'+(142+ow)+'" y="'+y+'" width="'+ww+'" height="22" fill="#a66335"/>'});
  s+='<text x="413" y="184" fill="#176b54" font-size="11">■ 油量</text><text x="495" y="184" fill="#92552f" font-size="11">■ 产水</text>';
 } else {
  var pts=[{charge:55,gun:90,density:12},{charge:70,gun:100,density:16},{charge:85,gun:115,density:20},{charge:95,gun:125,density:24}].map(penCandidate),cur=penCandidate(V),ref=bestPen();
  var px=function(x){return 58+500*x/650},py=function(x){return 165-1.4*x};
  s+='<text x="20" y="24" fill="#234b3f" font-size="13" font-weight="700">候选穿透—冲击约束图</text><path d="M58 35V165H570" fill="none" stroke="#567568" stroke-width="2"/>';
  s+='<line x1="'+px(400)+'" y1="35" x2="'+px(400)+'" y2="165" stroke="#a66335" stroke-width="2" stroke-dasharray="5 4"/><line x1="58" y1="'+py(75)+'" x2="570" y2="'+py(75)+'" stroke="#a66335" stroke-width="2" stroke-dasharray="5 4"/>';
  pts.forEach(function(p){s+='<circle cx="'+px(p.penetration)+'" cy="'+py(p.shock)+'" r="5" fill="#8fb7a0"/>'});
  [ref,cur].forEach(function(p,i){if(p)s+='<circle cx="'+px(p.penetration)+'" cy="'+py(p.shock)+'" r="'+(i?8:6)+'" fill="'+(i?'#a66335':'#176b54')+'" stroke="#fff" stroke-width="2"/>'});
  s+='<text x="'+(px(400)+6)+'" y="154" fill="#92552f" font-size="11">400 mm</text><text x="63" y="'+(py(75)-5)+'" fill="#92552f" font-size="11">冲击 75</text><text x="384" y="184" fill="#405c50" font-size="11">● 当前  ● 筛选参考</text>';
 }
 return s+'</svg>';
}
function lensNote(kind){return {co1:'左侧是当前权重份额，右侧是同一组权重下重算的候选分数；颜色和排序同时标注首选。',co2:'三层宽度表示候选经安全与出砂约束、帕累托筛选后逐级减少；阈值为教学设定。',co3:'同一口井的两端位置分别是压差排序和多信号风险排序；连线倾斜表示巡检优先级改变。',co4:'每段绿色与橙色长度对应合成模型算出的油量与产水；全关时两者均为零。',p1:'竖线为约 400 mm 污染带尺度，横线为教学冲击上限；当前点和参考点随输入与筛选更新。'}[kind]}
function calc(){var o={},chart='',note='',read='',kp=[],chartTitle='计算结果',compare=[],compareNote='';
 if(C.kind==='co1'){
  var candidates=[['裸眼',.86,.94,.20],['射孔',.76,.72,.46],['筛管',.69,.55,.72],['砾石充填',.61,.27,.88]],a=V.production,b=V.cost,c=V.water,z=.15;var sums=candidates.map(function(r){return [r[0],100*(a*r[1]+b*(1-r[2])+c*r[3]+z*Math.sqrt(r[1]*r[3]))/(a+b+c+z)]}).sort(function(x,y){return y[1]-x[1]});var chosen=candidates.filter(function(x){return x[0]===sums[0][0]})[0],base=candidates[0],baseScore=sums.filter(function(x){return x[0]===base[0]})[0][1];o={rank:sums};kp=[['教学综合首选',sums[0][0]],['首选分数',fmt(sums[0][1],1)],['候选数','4 种']];chart=bars(sums,105,'模糊评价教学分数');read=row('归一化权重合计',fmt(a+b+c+z,2))+row('首选与次选分差',fmt(sums[0][1]-sums[1][1],1))+row('模型边界','合成指标，不是现场选型');note='归一化指标与非线性项展示模糊综合评价的取舍，数值是教学合成数据。';chartTitle='四种完井方式的综合排序';compare=[compareCard('常规：只看产能',base[0],'产能 '+fmt(base[1],2)+'；成本 '+fmt(base[2],2)+'；控水 '+fmt(base[3],2),false),compareCard('智能辅助：教学综合排序',chosen[0],'产能 '+fmt(chosen[1],2)+'；成本 '+fmt(chosen[2],2)+'；控水 '+fmt(chosen[3],2),true),compareCard('当前权衡',sums[0][0]===base[0]?'两种规则同选':'首选发生改变','教学综合分比单看产能方案高 '+fmt(sums[0][1]-baseScore,1)+' 分',false)];compareNote='成本指数越小越省，控水指数越大越好；分数是论文评价思路的教学简化，不是论文实例或真实产量。';
 } else if(C.kind==='co2'){
  var cur=casing(V.density,V.diameter,V.phase),set=casingSet(cur),rec=set.recommend,feasible=cur.safety>=50&&cur.sand<=38,inFront=set.front.some(function(x){return x.density===cur.density&&x.diameter===cur.diameter&&x.phase===cur.phase});o={area:cur.area,safety:cur.safety,sand:cur.sand,feasible:feasible};kp=[['孔眼面积/米',fmt(cur.area,0)+' mm²'],['教学安全指数',fmt(cur.safety,1)],['教学出砂指数',fmt(cur.sand,1)]];chart=pareto(set,cur);read=row('几何面积公式','孔密 × π × (孔径/2)²')+row('教学约束','安全 ≥ 50；出砂 ≤ 38')+row('候选筛选',set.feasible.length+' 个可行 / '+set.front.length+' 个帕累托');note='灰色为教学约束外；绿色为可行与非支配候选。安全和出砂响应是合成数据，有限元仍需复核。';chartTitle='实际筛选出的教学帕累托解集';compare=[compareCard('单目标：只取最大面积',fmt(set.baseline.area,0)+' mm²/米','安全 '+fmt(set.baseline.safety,1)+'；出砂 '+fmt(set.baseline.sand,1),false),compareCard('多目标：可行帕累托参考',fmt(rec.area,0)+' mm²/米','孔密 '+rec.density+'；孔径 '+rec.diameter+'；安全 '+fmt(rec.safety,1),true),compareCard('当前滑块方案',feasible?(inFront?'可行且非支配':'可行但被支配'):'不满足教学约束','面积 '+fmt(cur.area,0)+'；安全 '+fmt(cur.safety,1)+'；出砂 '+fmt(cur.sand,1),false)];compareNote='面积由孔眼几何公式计算；安全 ≥ 50、出砂 ≤ 38 是教学阈值。帕累托方案指没有其他可行方案在三项目标上同时不差、且至少一项更好；筛选算法真实执行，合成响应仍需有限元和现场数据验证。';
 } else if(C.kind==='co3'){
  var names=['环空压差','低胶结质量','振动指数'],evaluated=riskEval(V),risk=evaluated.risk,contrib=evaluated.contrib,wells=[{name:'当前井',pressure:V.pressure,bond:V.bond,vibration:V.vibration},{name:'参照井 A',pressure:13,bond:82,vibration:2},{name:'参照井 B',pressure:6,bond:25,vibration:8},{name:'参照井 C',pressure:14,bond:50,vibration:6}];wells.forEach(function(w){w.risk=riskEval(w).risk});var byModel=wells.slice().sort(function(a,b){return b.risk-a.risk}),byPressure=wells.slice().sort(function(a,b){return b.pressure-a.pressure}),rank=byModel.findIndex(function(w){return w.name==='当前井'})+1,major=contrib.map(function(x){return Math.abs(x)}).indexOf(Math.max.apply(null,contrib.map(function(x){return Math.abs(x)})));o={risk:risk,rank:rank};kp=[['教学风险分数',fmt(risk,0)+'/100'],['模型巡检排位',rank+'/4'],['贡献幅度最大',names[major]]];chart=signedBars(names,contrib);read=row('当前井环空压差',fmt(V.pressure,0)+' MPa')+row('当前井胶结质量',fmt(V.bond,0)+'/100')+row('当前井振动指数',fmt(V.vibration,0)+'/10')+row('巡检名额','示意为 2 口 / 4 口');note='左右分别表示降低或提高本教学模型的风险分数；这是树桩贡献，不是论文的 SHAP 值。';chartTitle='教学树桩的有向特征贡献';compare=[compareCard('常规：仅按压差排前两口',byPressure.slice(0,2).map(function(w){return w.name}).join('、'),'忽略胶结和振动信息',false),compareCard('智能辅助：多信号风险前两口',byModel.slice(0,2).map(function(w){return w.name}).join('、'),'教学树桩评分；当前井第 '+rank+' 位',true),compareCard('当前井检查线索',names[major]+' '+(contrib[major]>=0?'增险':'降险'),'风险 '+fmt(risk,0)+'/100；先核验屏障证据',false)];compareNote='巡检排序只说明多信号辅助优先级；无真实失效标签，不能据此声称提高识别准确率。论文使用半监督、提升树与 SHAP，本演示只运行固定教学树桩。';
 } else if(C.kind==='co4'){
  var user=simSleeves([V.s1/100,V.s2/100,V.s3/100]),base=simSleeves([1,1,1]),ref=bestSleeves();o={oil:user.oilTotal,water:user.water[23],recommended:ref.opens};kp=[['24 月油量指数',fmt(user.oilTotal,1)],['24 月含水率',fmt(user.water[23],0)+'%'],['教学综合目标',fmt(user.reward,1)]];chart=curve([{name:'手动开度',values:user.oil},{name:'全开基线',values:base.oil},{name:'教学参考',values:ref.result.oil}],'累计产油指数曲线');read=row('当前段开度',V.s1+'% / '+V.s2+'% / '+V.s3+'%')+row('参考段开度',ref.opens.join('% / ')+'%')+row('教学奖励','累计油量 − 0.8 × 累计产水');note='三条曲线由相同的教学储层模型计算；参考开度来自离散候选搜索，不是论文 PER-MADDPG 策略。';chartTitle='两年累计油量：全开、手动与教学参考';chart+='<p class="chart-sub">24 月累计产水指数（教学）</p>'+bars([['手动产水',user.waterTotal],['全开产水',base.waterTotal],['参考产水',ref.result.waterTotal]],Math.max(base.waterTotal,user.waterTotal,ref.result.waterTotal)*1.15,'三方案累计产水指数');compare=[compareCard('常规：三段全开','100% / 100% / 100%','油量 '+fmt(base.oilTotal,1)+'；产水 '+fmt(base.waterTotal,1)+'；目标 '+fmt(base.reward,1),false),compareCard('当前手动开度',V.s1+'% / '+V.s2+'% / '+V.s3+'%','油量 '+fmt(user.oilTotal,1)+'；产水 '+fmt(user.waterTotal,1)+'；目标 '+fmt(user.reward,1),false),compareCard('教学候选搜索参考',ref.opens.join('% / ')+'%','油量 '+fmt(ref.result.oilTotal,1)+'；产水 '+fmt(ref.result.waterTotal,1)+'；目标 '+fmt(ref.result.reward,1),true)];compareNote='奖励权重 0.8 和 5% 搜索步长是明确的教学设定；论文 PER-MADDPG 的状态—联合动作—奖励—优先回放用于学习长期策略，本图未训练或复现该网络。';
 } else {
  var current=penCandidate(V),defaultCase=penCandidate({charge:72,gun:105,density:16}),best=bestPen(),rec=penFeasible(current)&&current.shock<best.shock?current:best,margin=current.penetration-400;o={penetration:current.penetration,shock:current.shock,feasible:penFeasible(current)};kp=[['教学预测穿透',fmt(current.penetration,0)+' mm'],['相对污染带',fmt(margin,0)+' mm'],['教学冲击指数',fmt(current.shock,0)]];chart=bars([['污染带尺度',400],['当前教学预测',current.penetration],['筛选参考预测',rec.penetration]],650,'穿透长度与污染带');read=row('合成训练样本','160 组')+row('教学模型','48 轮梯度提升树桩')+row('教学筛选条件','预测 ≥ 400 mm；冲击 ≤ 75')+row('工程复核','靶试、仿真、减震');note='预测来自合成样本训练的教学梯度提升树；400 mm 来自文23论文，不能用此演示判定现场安全。';chartTitle='预测穿透、污染带与筛选参考';compare=[compareCard('默认配置',defaultCase.charge+' / '+defaultCase.gun+' / '+defaultCase.density,'装药指数 / 枪径 mm / 孔密；预测 '+fmt(defaultCase.penetration,0)+' mm',false),compareCard('当前滑块配置',current.charge+' / '+current.gun+' / '+current.density,(penFeasible(current)?'满足':'未满足')+'教学筛选；冲击 '+fmt(current.shock,1),false),compareCard('预测筛选参考',rec.charge+' / '+rec.gun+' / '+rec.density,'预测 '+fmt(rec.penetration,0)+' mm；冲击 '+fmt(rec.shock,1),true)];compareNote='400 mm 是文23论文的污染带尺度；冲击 ≤ 75 是教学约束。参考方案由补充机器学习思路的合成预测器筛选，仍需靶试、冲击仿真和减震配置复核。';
 }
 $('scene').innerHTML=scene(C.kind,V,o);$('scene-explain').textContent=sceneCaption(C.kind);$('kpis').innerHTML=kp.map(function(x){return kpi(x[0],x[1])}).join('');$('comparison').innerHTML=compare.join('');$('compare-note').textContent=compareNote;$('insight').innerHTML=decisionLens(C.kind,o);$('insight-note').textContent=lensNote(C.kind);$('chart').innerHTML=chart;$('chart-title').textContent=chartTitle;$('chart-note').textContent=note;$('readout').innerHTML=read;
}
function init(){document.title=C.title+' · 案例演示';$('title').textContent=C.title;$('intro').textContent=C.intro;$('reported').textContent=C.reported;$('boundary').textContent=C.metrics;var html='';C.controls.forEach(function(c){V[c.key]=c.value;html+='<div class="ctl"><div class="ctl-line"><label for="ctl-'+c.key+'">'+esc(c.label)+'</label><strong id="v-'+c.key+'">'+c.value+'</strong></div><input id="ctl-'+c.key+'" type="range" min="'+c.min+'" max="'+c.max+'" step="'+c.step+'" value="'+c.value+'"><div class="ends"><span>'+c.min+'</span><span>'+c.max+'</span></div></div>'});$('controls').innerHTML=html;C.controls.forEach(function(c){$('ctl-'+c.key).addEventListener('input',function(e){V[c.key]=Number(e.target.value);$('v-'+c.key).textContent=e.target.value;calc()})});$('reset').addEventListener('click',function(){C.controls.forEach(function(c){V[c.key]=c.value;$('ctl-'+c.key).value=c.value;$('v-'+c.key).textContent=c.value});calc()});calc()}init();
})();